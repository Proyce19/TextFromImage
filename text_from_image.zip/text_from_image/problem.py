import text_creator as TC
from sklearn.ensemble import RandomForestClassifier
import cv2
import glob
import numpy as np
def print_letter(x):
    y=""
    if x[0]==1:
        y="a"

    elif x[0]==2:
        y="b"
    elif x[0]==3:
        y="c"
    elif x[0]==4:
        y="d"
    elif x[0]==5:
        y="e"
    elif x[0]==6:
        y="f"
    elif x[0]==7:
        y="g"
    elif x[0]==8:
        y="h"
    elif x[0]==9:
        y="i"
    elif x[0]==10:
        y="j"
    elif x[0]==11:
        y="k"
    elif x[0]==12:
        y="l"
    elif x[0]==13:
        y="m"
    elif x[0]==14:
        y="n"
    elif x[0]==15:
        y="o"
    elif x[0]==16:
        y="p"
    elif x[0]==17:
        y="q"
    elif x[0]==18:
        y="r"
    elif x[0]==19:
        y="s"
    elif x[0]==20:
        y="t"
    elif x[0]==21:
        y="u"
    elif x[0]==22:
        y="v"
    elif x[0]==23:
        y="w"
    elif x[0]==24:
        y="x"
    elif x[0]==25:
        y="y"
    elif x[0]==26:
        y="z"
    return y



def get_ref_contour(img):
    ref_gray = img
    ret, thresh = cv2.threshold(ref_gray,50,255,cv2.THRESH_BINARY)
    i,contours, hierarchy = cv2.findContours(thresh,1,2)
    for contour in contours:
        area = cv2.contourArea(contour)

        img_area = img.shape[0] * img.shape[1]
        if 0.05 < area/float(img_area)<0.99:
            return contour


def get_all_contours(img):

    ref_gray = img
    ret, thresh = cv2.threshold(ref_gray, 50, 255, cv2.THRESH_BINARY)
    i, contours, hierarchy = cv2.findContours(thresh, 1, 2)
    return contours
def get_all_contours2(img):

    l=[]
    ref_gray = img
    ret, thresh = cv2.threshold(ref_gray, 0, 255, cv2.THRESH_BINARY)
    i, contours, hierarchy = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_TC89_L1)
    for c in contours:
        if 0.05<cv2.contourArea(c)/(img.shape[0]*img.shape[1])<0.7:
            l.append(c)
    return l
def contours_format(contour):
    cont_np_array=[]

    for i in contour:
        for j in i:
            for k in j:
                cont_np_array.append(k)
    #cont_np_array=np.array(cont_np_array)
    #cont_np_array=np.reshape(cont_np_array,(contour.shape[0],2))
    return cont_np_array

def set_for_calculation(cf):
    sum=0
    p=[]
    for i in cf:
        sum = sum + i
    sum = sum / len(cf)
    # print("SUM: ", sum)
    p.append(sum)
    p = np.array(p)
    p = np.reshape(p, (1, 1))
    # print(len(p))
    return p
if __name__ == "__main__":
    d=[1,2,3]
    t=[0,1,2]
    d=np.array(d)
    t=np.array(t)
    d=np.reshape(d,(3,1))
    t=np.reshape(t,(3,1))
    target_class = [1,1,2,3,4,5,6,7,8,9,9,9,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]
    target_class= np.reshape(target_class,(30,1))
    #print(target_class)
    images=[]
    imgs=[]
    contours = []
    for files in glob.glob("data\\*.png"):
        img = cv2.imread(files,0)
        #img=cv2.resize(img,(60,60))
        a = get_ref_contour(img)
        images.append(a)
        cf = contours_format(a)
        contours.append(cf)



    avgs=[]
    for i in contours:
        sum = 0
        for j in i:
          sum+=j
        sum=sum/len(i)
        avgs.append(sum)
    avgs=np.array(avgs)
    avgs=np.reshape(avgs,(30,1))
    #print(avgs)
    classifier = RandomForestClassifier()
    classifier.fit(avgs,target_class)

    img_test = cv2.imread('hh.jpg',0)
    #img_test = cv2.resize(img_test,(60,60))


    input_contours = get_all_contours(img_test)
    print("1: ", len(input_contours))
    input_contours.pop()
    input_contours.pop()

    print("2: ",len(input_contours))
    #print("1: ",input_contours)
    #input_contours = sorted(input_contours, key=cv2.contourArea, reverse=True)
    #print("2: ",input_contours)
    img_test=cv2.cvtColor(img_test,cv2.COLOR_GRAY2BGR)
    #cv2.drawContours(img_test,[input_contours],-1,(0,255,0),1)

    for i in input_contours:
        cv2.drawContours(img_test, [i], -1, (0, 255, 0), 1)

    cv2.imshow("dsds", img_test)
    cv2.waitKey(0)
    cv2.destroyAllWindows()





    strx=""
    for i in reversed(input_contours):
        min_dist = 999999999
        closest_contour = input_contours[0]
        for j in reversed(images):
       # ret = cv2.matchShapes(j, i, 1, 0.0)
                x = cv2.matchShapes(i,j,1,0.0)
                if x <= min_dist:
                    min_dist = x
                    closest_contour = j


    # print(closest_contour)

        cf = contours_format(closest_contour)

        p=set_for_calculation(cf)

        #print("Prediction: \n")
        #print(print_letter(classifier.predict(p)))

        strx=strx+print_letter(classifier.predict(p))

    #img_test=cv2.cvtColor(img_test,cv2.COLOR_GRAY2BGR)
    #cv2.drawContours(img_test, [closest_contour], -1, (0, 255, 0), 3)
    #cv2.imshow("Drawing",img_test)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()
    print("STRX: ",strx)
    tc = TC



    s=tc.segment(strx)
    s=str(s)
    with open("file.txt","w") as file:
        file.write(str(s))










